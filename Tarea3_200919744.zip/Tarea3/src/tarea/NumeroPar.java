package tarea;
import java.util.Scanner;

public class NumeroPar {

	public static void main(String[] args) {
		Scanner lectura = new Scanner(System.in);
		int numE;
		
		System.out.print("Ingrese un numero entero: ");
		numE = lectura.nextInt();
		
		System.out.println(numE%2 == 0?"El numero es Par":"El numero es impar");

	}//Fin del m�todo principal main.

}//Fin del la clase NumeroPar
